/* Deploy-time configuration for the DEPLOYED build.
 *
 * useRealApi: false serves the in-memory demo data, because the API is not
 * deployed — and a page served over HTTPS cannot call an http://127.0.0.1 API
 * anyway; the browser blocks it as mixed content.
 *
 * To repoint at a real API: overwrite this one file in $web and purge Front
 * Door. No rebuild. See docs/DEPLOYMENT.md. */
window.__SPMS_CONFIG__ = {
  useRealApi: false,
};
